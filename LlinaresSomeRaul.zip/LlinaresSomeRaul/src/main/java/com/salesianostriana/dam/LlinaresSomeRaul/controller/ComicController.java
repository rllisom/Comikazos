package com.salesianostriana.dam.LlinaresSomeRaul.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;


import com.salesianostriana.dam.LlinaresSomeRaul.service.ComicService;

@Controller
@RequestMapping("/ck")
public class ComicController {

	@Autowired
	private ComicService comicService;
	
	
	//GET ALL
	/*@GetMapping("/comic")
	public String getAll(Model model) {
		model.addAttribute(comicService.getAll());
		return "index";
	}*/
	
	//GET 5 BEST
	@GetMapping("/top")
	public String getBest(Model model){
		model.addAttribute("comics", comicService.getBest());
		return "principal";
	}

	//GET CATALOGUE
	@GetMapping("/catalogue")
	public String getCatalogue(Model model){
		model.addAttribute("comicList",comicService.getCatalogue());
		return "principal";
	}

	//GET BY ID
	/*@GetMapping("/{id}")
	public String getById(@RequestParam Long id, Model model) {
		model.addAttribute("comic", comicService.getByid(id));
		return "index";
	}*/
}
