package com.salesianostriana.dam.LlinaresSomeRaul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LlinaresSomeRaulApplication {

	public static void main(String[] args) {
		SpringApplication.run(LlinaresSomeRaulApplication.class, args);
	}

}
